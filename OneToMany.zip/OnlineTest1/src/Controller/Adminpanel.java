package Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("Adminpanel")
public class Adminpanel {

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		ModelAndView mandv=new ModelAndView();
		mandv.setViewName("admin");
		return mandv;
	}
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(HttpSession session)
	{
		ModelAndView mandv=new ModelAndView();
		HiberAction dba=new HiberAction();
		 mandv.setViewName("createTest");
	return mandv;

}
}
